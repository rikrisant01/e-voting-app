// Backend API: ubah jika folder backend dipasang di alamat lain.
const API = '../backend/api/';
let csrfToken = '';
let currentUser = null;

async function api(path, options={}) {
  const headers = {'Content-Type':'application/json', ...(options.headers||{})};
  if (options.method && options.method !== 'GET' && csrfToken) headers['X-CSRF-Token'] = csrfToken;
  const response = await fetch(API + path, {...options, headers, credentials:'same-origin'});
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || 'Permintaan gagal.');
  return data;
}
function show(id, yes=true){document.getElementById(id).classList.toggle('hidden',!yes);}
async function init(){
  const csrf=await fetch(API+'csrf.php',{credentials:'same-origin'}).then(r=>r.json());
  csrfToken=csrf.token;
  const me=await api('me.php');
  if(me.user){currentUser=me.user;showApp();} else show('loginView');
}
document.getElementById('loginForm').addEventListener('submit',async e=>{
  e.preventDefault();const form=new FormData(e.target);
  try{
    const data=await api('login.php',{method:'POST',body:JSON.stringify({nis:form.get('nis'),password:form.get('password')})});
    currentUser=data.user;document.getElementById('loginMsg').textContent='';e.target.reset();showApp();
  }catch(err){document.getElementById('loginMsg').textContent=err.message;}
});
document.getElementById('logoutBtn').addEventListener('click',async()=>{
  try{await api('logout.php',{method:'POST',body:'{}'});location.reload();}catch(err){alert(err.message);}
});
function showApp(){
  show('loginView',false);show('appView');show('logoutBtn');
  document.getElementById('welcome').textContent='Selamat datang, '+currentUser.nama;
  document.getElementById('roleInfo').textContent='Login sebagai '+currentUser.role;
  if(currentUser.role==='admin'){show('adminPanel');show('studentPanel',false);loadAdminCandidates();}
  else {show('studentPanel');show('adminPanel',false);loadStudent();}
  loadResults();
}
async function loadStudent(){
  try{
    const status=await api('status_vote.php');
    document.getElementById('voteStatus').textContent=status.has_voted?'Kamu sudah menggunakan hak pilih.':'Silakan pilih satu kandidat. Pilihan tidak dapat diubah.';
    const data=await api('candidates.php');const box=document.getElementById('candidates');box.innerHTML='';
    data.data.forEach(k=>{
      const el=document.createElement('article');el.className='candidate';
      const title=document.createElement('h3');title.textContent=k.nama;
      const cls=document.createElement('p');cls.textContent='Kelas: '+k.kelas;
      const vm=document.createElement('p');vm.textContent=k.visi_misi;
      el.append(title,cls,vm);
      if(!status.has_voted){const btn=document.createElement('button');btn.textContent='Pilih kandidat';btn.onclick=()=>castVote(k.id);el.append(btn);}
      box.append(el);
    });
  }catch(err){document.getElementById('candidates').textContent=err.message;}
}
async function castVote(id){
  if(!confirm('Yakin memilih kandidat ini? Pilihan tidak dapat diubah.'))return;
  try{const r=await api('vote.php',{method:'POST',body:JSON.stringify({kandidat_id:id})});alert(r.message);loadStudent();loadResults();}
  catch(err){alert(err.message);loadStudent();}
}
async function loadResults(){
  try{const r=await api('results.php');document.getElementById('totalVotes').textContent='Total suara masuk: '+r.total;
    const table=document.createElement('table');table.innerHTML='<tr><th>Kandidat</th><th>Kelas</th><th>Suara</th></tr>';
    r.data.forEach(item=>{const tr=document.createElement('tr');[item.nama,item.kelas,item.jumlah_suara].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.append(td);});table.append(tr);});
    const box=document.getElementById('results');box.replaceChildren(table);
  }catch(err){document.getElementById('results').textContent=err.message;}
}
document.getElementById('candidateForm').addEventListener('submit',async e=>{
  e.preventDefault();const f=new FormData(e.target);
  try{const r=await api('admin/candidates.php',{method:'POST',body:JSON.stringify({nama:f.get('nama'),kelas:f.get('kelas'),visi_misi:f.get('visi_misi')})});document.getElementById('adminMsg').textContent=r.message;e.target.reset();loadAdminCandidates();loadResults();}
  catch(err){document.getElementById('adminMsg').textContent=err.message;}
});
async function loadAdminCandidates(){
  try{const r=await api('admin/candidates.php');const box=document.getElementById('adminCandidates');box.innerHTML='';
    r.data.forEach(k=>{const row=document.createElement('p');row.textContent=k.nama+' ('+k.kelas+') ';
      const btn=document.createElement('button');btn.className='secondary';btn.textContent='Hapus';btn.onclick=async()=>{
        if(!confirm('Hapus kandidat '+k.nama+'?'))return;
        try{const out=await api('admin/delete_candidate.php',{method:'POST',body:JSON.stringify({id:k.id})});alert(out.message);loadAdminCandidates();loadResults();}
        catch(err){alert(err.message);}
      };row.append(btn);box.append(row);});
  }catch(err){document.getElementById('adminCandidates').textContent=err.message;}
}
init().catch(err=>{document.getElementById('loginMsg').textContent='Gagal terhubung ke backend: '+err.message;});
