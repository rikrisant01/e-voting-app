<?php
declare(strict_types=1);
session_start();

$host = 'localhost';
$dbname = 'evoting_osis';
$dbuser = 'root';
$dbpass = ''; // Sesuaikan dengan MySQL kamu.

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser,
        $dbpass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

function jsonOut(array $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function body(): array {
    $data = json_decode(file_get_contents('php://input'), true);
    return is_array($data) ? $data : [];
}
function requireLogin(): array {
    if (empty($_SESSION['user'])) jsonOut(['ok'=>false,'message'=>'Silakan login terlebih dahulu.'], 401);
    return $_SESSION['user'];
}
function requireRole(string $role): array {
    $user = requireLogin();
    if ($user['role'] !== $role) jsonOut(['ok'=>false,'message'=>'Akses ditolak.'], 403);
    return $user;
}
function requireCsrf(): void {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
        jsonOut(['ok'=>false,'message'=>'Token keamanan tidak valid. Muat ulang halaman.'], 419);
    }
}
