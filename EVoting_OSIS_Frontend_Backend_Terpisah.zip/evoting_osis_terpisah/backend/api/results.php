<?php
require_once __DIR__.'/../config.php';
requireLogin();
$sql='SELECT k.id,k.nama,k.kelas,COUNT(v.id) AS jumlah_suara FROM kandidat k LEFT JOIN voting v ON v.kandidat_id=k.id GROUP BY k.id,k.nama,k.kelas ORDER BY jumlah_suara DESC,k.id';
$data=$pdo->query($sql)->fetchAll();
$total=(int)$pdo->query('SELECT COUNT(*) FROM voting')->fetchColumn();
jsonOut(['ok'=>true,'total'=>$total,'data'=>$data]);
