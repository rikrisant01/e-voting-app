<?php
require_once __DIR__.'/../config.php';
$user=requireRole('siswa');
$stmt=$pdo->prepare('SELECT id FROM voting WHERE user_id=?'); $stmt->execute([$user['id']]);
jsonOut(['ok'=>true,'has_voted'=>(bool)$stmt->fetch()]);
