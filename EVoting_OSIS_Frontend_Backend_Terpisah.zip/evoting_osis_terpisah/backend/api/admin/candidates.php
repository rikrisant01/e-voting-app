<?php
require_once __DIR__.'/../../config.php';
requireRole('admin');
if ($_SERVER['REQUEST_METHOD']==='GET') {
    $data=$pdo->query('SELECT id,nama,kelas,visi_misi,foto FROM kandidat ORDER BY id')->fetchAll();
    jsonOut(['ok'=>true,'data'=>$data]);
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    requireCsrf(); $d=body();
    $nama=trim($d['nama']??''); $kelas=trim($d['kelas']??''); $visi=trim($d['visi_misi']??'');
    if (!$nama || !$kelas || !$visi) jsonOut(['ok'=>false,'message'=>'Semua kolom wajib diisi.'],422);
    $stmt=$pdo->prepare('INSERT INTO kandidat(nama,kelas,visi_misi) VALUES(?,?,?)');
    $stmt->execute([$nama,$kelas,$visi]);
    jsonOut(['ok'=>true,'message'=>'Kandidat berhasil ditambahkan.']);
}
jsonOut(['ok'=>false,'message'=>'Metode tidak diizinkan.'],405);
