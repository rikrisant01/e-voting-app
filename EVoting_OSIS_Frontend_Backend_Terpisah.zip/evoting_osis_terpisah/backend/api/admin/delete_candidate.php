<?php
require_once __DIR__.'/../../config.php';
requireRole('admin');
if ($_SERVER['REQUEST_METHOD']!=='POST') jsonOut(['ok'=>false,'message'=>'Metode tidak diizinkan.'],405);
requireCsrf(); $d=body(); $id=(int)($d['id']??0);
try {
    $stmt=$pdo->prepare('DELETE FROM kandidat WHERE id=?'); $stmt->execute([$id]);
    jsonOut(['ok'=>true,'message'=>'Kandidat berhasil dihapus.']);
} catch(PDOException $e) {
    jsonOut(['ok'=>false,'message'=>'Kandidat tidak bisa dihapus karena sudah memiliki suara.'],409);
}
