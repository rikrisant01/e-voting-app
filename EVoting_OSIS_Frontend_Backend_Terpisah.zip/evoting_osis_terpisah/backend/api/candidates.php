<?php
require_once __DIR__.'/../config.php';
requireLogin();
$data=$pdo->query('SELECT id,nama,kelas,visi_misi,foto FROM kandidat ORDER BY id')->fetchAll();
jsonOut(['ok'=>true,'data'=>$data]);
