<?php
require_once __DIR__.'/../config.php';
if (empty($_SESSION['user'])) jsonOut(['ok'=>true,'user'=>null]);
jsonOut(['ok'=>true,'user'=>$_SESSION['user']]);
