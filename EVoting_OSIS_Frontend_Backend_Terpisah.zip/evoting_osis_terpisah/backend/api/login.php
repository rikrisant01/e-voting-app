<?php
require_once __DIR__.'/../config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonOut(['ok'=>false,'message'=>'Metode tidak diizinkan.'],405);
requireCsrf();
$data=body(); $nis=trim($data['nis']??''); $password=$data['password']??'';
$stmt=$pdo->prepare('SELECT id,nis,password,nama,role FROM users WHERE nis=? LIMIT 1');
$stmt->execute([$nis]); $u=$stmt->fetch();
if (!$u || !password_verify($password,$u['password'])) jsonOut(['ok'=>false,'message'=>'Username/NIS atau password salah.'],401);
session_regenerate_id(true);
unset($u['password']); $_SESSION['user']=$u;
jsonOut(['ok'=>true,'user'=>$u]);
