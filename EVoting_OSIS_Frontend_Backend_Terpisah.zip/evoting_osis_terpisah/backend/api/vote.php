<?php
require_once __DIR__.'/../config.php';
$user=requireRole('siswa');
if ($_SERVER['REQUEST_METHOD']!=='POST') jsonOut(['ok'=>false,'message'=>'Metode tidak diizinkan.'],405);
requireCsrf();
$data=body(); $kid=(int)($data['kandidat_id']??0);
$check=$pdo->prepare('SELECT id FROM kandidat WHERE id=?'); $check->execute([$kid]);
if (!$check->fetch()) jsonOut(['ok'=>false,'message'=>'Kandidat tidak ditemukan.'],404);
try {
    $stmt=$pdo->prepare('INSERT INTO voting (user_id,kandidat_id) VALUES (?,?)');
    $stmt->execute([$user['id'],$kid]);
    jsonOut(['ok'=>true,'message'=>'Suara berhasil disimpan. Terima kasih sudah memilih.']);
} catch (PDOException $e) {
    if ($e->getCode()==='23000') jsonOut(['ok'=>false,'message'=>'Kamu sudah pernah melakukan voting.'],409);
    jsonOut(['ok'=>false,'message'=>'Terjadi kesalahan saat menyimpan suara.'],500);
}
