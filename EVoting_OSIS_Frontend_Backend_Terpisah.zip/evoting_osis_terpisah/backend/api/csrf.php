<?php
require_once __DIR__.'/../config.php';
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
jsonOut(['ok'=>true,'token'=>$_SESSION['csrf']]);
