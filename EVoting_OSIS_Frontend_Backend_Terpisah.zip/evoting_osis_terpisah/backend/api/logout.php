<?php
require_once __DIR__.'/../config.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') jsonOut(['ok'=>false,'message'=>'Metode tidak diizinkan.'],405);
requireCsrf();
$_SESSION=[]; session_destroy();
jsonOut(['ok'=>true]);
