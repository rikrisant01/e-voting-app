<?php
// Jalankan sekali, buat akun admin, lalu HAPUS file ini.
require_once __DIR__.'/config.php';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $nama=trim($_POST['nama']??''); $username=trim($_POST['username']??''); $password=$_POST['password']??'';
    if ($nama && $username && strlen($password)>=8) {
        try {
            $stmt=$pdo->prepare("INSERT INTO users(nis,password,nama,role) VALUES(?,?,?,'admin')");
            $stmt->execute([$username,password_hash($password,PASSWORD_DEFAULT),$nama]);
            $msg='Admin berhasil dibuat. Hapus file setup_admin.php sekarang.';
        } catch(PDOException $e) {$msg='Username sudah digunakan.';}
    } else {$msg='Isi semua data. Password minimal 8 karakter.';}
}
?><!doctype html><html lang="id"><meta charset="utf-8"><title>Buat Admin</title>
<h2>Buat akun Admin</h2><p><?= htmlspecialchars($msg??'') ?></p>
<form method="post"><p>Nama <input name="nama" required></p><p>Username <input name="username" required></p>
<p>Password <input type="password" name="password" minlength="8" required></p><button>Buat Admin</button></form></html>
