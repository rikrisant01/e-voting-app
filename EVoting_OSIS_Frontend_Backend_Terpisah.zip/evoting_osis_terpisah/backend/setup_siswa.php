<?php
// Untuk demo, buat akun siswa. HAPUS file ini setelah selesai.
require_once __DIR__.'/config.php';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $nama=trim($_POST['nama']??''); $nis=trim($_POST['nis']??''); $password=$_POST['password']??'';
    if ($nama && $nis && strlen($password)>=8) {
        try {
            $stmt=$pdo->prepare("INSERT INTO users(nis,password,nama,role) VALUES(?,?,?,'siswa')");
            $stmt->execute([$nis,password_hash($password,PASSWORD_DEFAULT),$nama]);
            $msg='Akun siswa berhasil dibuat. Hapus file setup_siswa.php setelah selesai.';
        } catch(PDOException $e) {$msg='NIS sudah digunakan.';}
    } else {$msg='Lengkapi data. Password minimal 8 karakter.';}
}
?><!doctype html><html lang="id"><meta charset="utf-8"><title>Buat Siswa</title>
<h2>Buat akun Siswa</h2><p><?= htmlspecialchars($msg??'') ?></p>
<form method="post"><p>Nama <input name="nama" required></p><p>NIS <input name="nis" required></p>
<p>Password <input type="password" name="password" minlength="8" required></p><button>Buat Siswa</button></form></html>
