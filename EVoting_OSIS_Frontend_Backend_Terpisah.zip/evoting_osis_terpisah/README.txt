E-VOTING OSIS - FRONTEND DAN BACKEND TERPISAH
=============================================

STRUKTUR
- frontend/ : HTML, CSS, JavaScript (tampilan dan interaksi).
- backend/  : PHP API, koneksi database, login, voting, hasil, pengelolaan kandidat.
- database.sql : struktur database users, kandidat, voting.

CARA MENJALANKAN
1. Ekstrak folder evoting_osis_terpisah ke C:\xampp\htdocs\
2. Jalankan Apache dan MySQL dari XAMPP.
3. Buka phpMyAdmin, pilih Import, lalu impor database.sql.
4. Periksa backend/config.php. Default XAMPP: user root, password kosong.
5. Buat admin dengan membuka:
   http://localhost/evoting_osis_terpisah/backend/setup_admin.php
6. Buat akun siswa melalui:
   http://localhost/evoting_osis_terpisah/backend/setup_siswa.php
   Ulangi untuk setiap siswa.
7. HAPUS backend/setup_admin.php dan backend/setup_siswa.php setelah akun dibuat.
8. Buka frontend:
   http://localhost/evoting_osis_terpisah/frontend/

CARA KERJA
- Frontend mengirim permintaan fetch() ke file PHP API di backend/api/.
- Backend memeriksa sesi login dan role pengguna.
- Password dibuat dengan password_hash() dan diperiksa dengan password_verify().
- Tabel voting memiliki UNIQUE pada user_id sehingga satu akun siswa hanya dapat memilih satu kali.

PENTING
- Jalankan frontend dan backend melalui alamat localhost yang sama seperti instruksi di atas.
- Versi ini memisahkan tampilan dan proses server, tetapi keduanya tetap berjalan di satu project XAMPP.
- Admin dan siswa disimpan pada tabel users dengan role berbeda.
- Contoh pembelajaran. Untuk pemilihan resmi perlu pengujian keamanan, pengaturan periode voting,
  pembatasan kapan hasil boleh dilihat, audit log, backup, HTTPS, serta prosedur verifikasi.
